# 提出用チェックポイント

2026-10-05。ユーザー指示: **日本時間7:00で作業を一旦停止し、進捗・成果物・使い方を報告する。** 自動フォローアップ `7-saa` を7:00に設定済み。報告後にそのフォローアップを停止し、新規作業は再開指示を待つ。

## 利用可能なもの

- **先行学習版**: 第1章AWS全体像、第2章IAM。6レッスン・基礎20問・用語21件。
- PWA: テキスト、用語検索、採点、全選択肢の解説、誤答/自信なしの復習、読了、ブックマーク、端末保存、JSONバックアップ。
- オフライン: 全ファイル保存確認、通信遮断での再読込、未閲覧教材・新規ページからの起動、更新失敗時旧版維持、明示的な新版適用、欠落キャッシュ修復。
- EPUBと単一HTML: 同じ確認対象の教材・問題・解説。電子書籍版は自動採点なし。

## 成果物

- `deliverables/SAA-starter.epub`: iPhoneのブックへ取り込む電子書籍。
- `deliverables/SAA-starter.html`: 通信・JavaScriptなしで読める単一HTML。
- `deliverables/SAA-starter-app.zip`: ビルド済みPWAとWindows起動用ファイル。
- `deliverables/SAA-project-source.zip`: 原稿・コード・設計・タスク台帳・テストのソース一式。
- `deliverables/使い方.md`: iPhoneの電子書籍、Windowsアプリ、PWA公開手順。
- `Start-Learning.cmd`: 現在のPCで起動後、`http://127.0.0.1:4180/` を開く。Node.jsを使用。別PCはNode.js 22以降が必要。

## 検証

- `pnpm test`: 9件成功。
- `pnpm build`: TypeScript型検査と配信用ビルド成功。
- `scripts/browser-check.mjs`: Chromeのモバイル幅で先行版の学習・オフライン・バックアップ成功。
- `scripts/update-check.mjs`: 更新失敗、待機、適用、キャッシュ修復のブラウザー試験成功。
- `scripts/book-browser-check.mjs`: JavaScript無効のChromeでHTML教材表示・問題解説リンク成功。
- EPUB: ZIP CRCとXML/XHTML/OPF構文、ファイル参照・20問の解説を確認。
- 視覚確認: `artifacts/home-mobile.png`, `question-mobile.png`, `book-mobile.png`。

## 完成していないもの

全12章36レッスン・通常200問の原稿はソースにあるが、詳細範囲の不足や用語整理が残り、全問題の監査も未完了。公開対象は `src/content/index.ts` で2章20問に限定。

模試65問×2の問題は未作成。模試のUIと保存処理はあるが、未検証で開始できない。ゲームは教材監査が前提のため未着手。

公開先アカウント・GitHubリポジトリが未接続なのでHTTPS公開は未実施。iPhone Safari・Apple Booksの実機表示は未確認。OneDriveの端末間同期も未確認。

サブエージェント3名は利用上限で停止した。親が作成途中の構文を整え、2章20問を確認・補足し、動作版へ統合した。先行版を全計画の完成と報告しないこと。

## 再開時の順序

1. ユーザーのiPhone受入結果と公開先を確認。
2. CONTENT_REVIEW.mdのCR-001〜009を章別タスクで修正。
3. 通常問題q021〜200の内容・根拠・重複を監査し、確認済み分を公開対象に追加。
4. 模試2回を新規作成・監査し、模試機能の統合検証。
5. 教材全体監査が通過してからG1以降へ。
